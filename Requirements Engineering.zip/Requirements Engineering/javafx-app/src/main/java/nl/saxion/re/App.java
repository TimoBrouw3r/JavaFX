package nl.saxion.re; 

public class App{
    public static void main(String[] args){
        FXApp.main(args);
    }
}
